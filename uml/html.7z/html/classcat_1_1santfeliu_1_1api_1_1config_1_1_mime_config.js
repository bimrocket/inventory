var classcat_1_1santfeliu_1_1api_1_1config_1_1_mime_config =
[
    [ "customize", "classcat_1_1santfeliu_1_1api_1_1config_1_1_mime_config.html#a4a9d37d8b34246ce6b601c62b734f770", null ]
];