var classcat_1_1santfeliu_1_1api_1_1beans_1_1_response_wfs_container =
[
    [ "getHttpStatus", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_response_wfs_container.html#a07d127bb505472d00825d33176afe986", null ],
    [ "getResponse", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_response_wfs_container.html#a9e1388add4578e14951ec3a7086518e4", null ],
    [ "setHttpStatus", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_response_wfs_container.html#af041c7f9759fc3374b1ef5bfde98b9b6", null ],
    [ "setResponse", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_response_wfs_container.html#a3ea39dd001af28c72ec802fb1b9502ec", null ]
];