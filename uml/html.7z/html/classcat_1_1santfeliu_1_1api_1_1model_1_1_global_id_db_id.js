var classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id =
[
    [ "GlobalIdDbId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id.html#a6cce1e46504241be45f47e612a8f9efa", null ],
    [ "GlobalIdDbId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id.html#a7fb3a26db902251fe6b48c5a9b893324", null ],
    [ "getGlobalId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id.html#ae9dd079702a710f68a8b5165119607fe", null ],
    [ "getInventoryName", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id.html#ab9099b8cf4bf88f98ffd6596e381dde1", null ],
    [ "getLocalId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id.html#a0762375f7ddecd3d67e826e4053a40fd", null ],
    [ "setGlobalId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id.html#a28fd47971c45b2f27e0a3fdb00c6e0e4", null ],
    [ "setInventoryName", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id.html#a049a93295d1dd96400dd6b7f41fd8d0c", null ],
    [ "setLocalId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db_id.html#a1f7dfe7f4e0ff04ad83e49c3797f22ec", null ]
];