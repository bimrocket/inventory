var namespacecat_1_1santfeliu_1_1api_1_1loaders =
[
    [ "GeoserverLoader", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_geoserver_loader.html", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_geoserver_loader" ],
    [ "JSONKafkaLoader", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_j_s_o_n_kafka_loader.html", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_j_s_o_n_kafka_loader" ]
];