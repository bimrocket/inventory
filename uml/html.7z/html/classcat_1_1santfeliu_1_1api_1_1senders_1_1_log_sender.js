var classcat_1_1santfeliu_1_1api_1_1senders_1_1_log_sender =
[
    [ "send", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_log_sender.html#ac06d58a32b5ef3c30db521b26faa3b1c", null ]
];