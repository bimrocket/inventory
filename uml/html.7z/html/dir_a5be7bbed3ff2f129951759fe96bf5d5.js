var dir_a5be7bbed3ff2f129951759fe96bf5d5 =
[
    [ "inventari", "dir_ee165daa346f44ec212d4973d6c8819d.html", "dir_ee165daa346f44ec212d4973d6c8819d" ]
];