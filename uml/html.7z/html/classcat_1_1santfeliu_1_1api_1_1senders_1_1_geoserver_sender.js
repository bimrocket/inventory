var classcat_1_1santfeliu_1_1api_1_1senders_1_1_geoserver_sender =
[
    [ "send", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_geoserver_sender.html#af5b140e878d0004c6631e15dfa27c3cd", null ],
    [ "sendPostXML", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_geoserver_sender.html#ae7b0cb718191fb2711480c4c5f0ebcff", null ]
];