var interfacecat_1_1santfeliu_1_1api_1_1repo_1_1_global_id_repo =
[
    [ "findByInventory", "interfacecat_1_1santfeliu_1_1api_1_1repo_1_1_global_id_repo.html#aa494824708295a6245e0a3874aa8c8b0", null ],
    [ "findByInventoryAndGlobalId", "interfacecat_1_1santfeliu_1_1api_1_1repo_1_1_global_id_repo.html#af4a2a90ce986bb54b7a1c29d44be5346", null ],
    [ "findByInventoryAndLocalId", "interfacecat_1_1santfeliu_1_1api_1_1repo_1_1_global_id_repo.html#ab03e35536b2de22c826afe02fd7ae2b4", null ]
];