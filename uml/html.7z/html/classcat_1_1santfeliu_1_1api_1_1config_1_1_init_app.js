var classcat_1_1santfeliu_1_1api_1_1config_1_1_init_app =
[
    [ "init", "classcat_1_1santfeliu_1_1api_1_1config_1_1_init_app.html#aafd96bc95a6a713acbdc6273d6ca2159", null ],
    [ "onApplicationEvent", "classcat_1_1santfeliu_1_1api_1_1config_1_1_init_app.html#aead95e1a038bfa63eaa6744eb949ffb0", null ]
];