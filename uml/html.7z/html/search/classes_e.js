var searchData=
[
  ['websecurityconfig_504',['WebSecurityConfig',['../classcat_1_1santfeliu_1_1api_1_1config_1_1_web_security_config.html',1,'cat::santfeliu::api::config']]]
];
