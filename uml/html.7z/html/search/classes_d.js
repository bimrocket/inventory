var searchData=
[
  ['simplecorsfilter_503',['SimpleCorsFilter',['../classcat_1_1santfeliu_1_1api_1_1config_1_1_simple_cors_filter.html',1,'cat::santfeliu::api::config']]]
];
