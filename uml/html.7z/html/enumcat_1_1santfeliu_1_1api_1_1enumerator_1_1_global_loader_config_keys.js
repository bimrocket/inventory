var enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys =
[
    [ "getDescription", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys.html#a99c0c56469402cd43c3d0f416cf9b350", null ],
    [ "getKey", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys.html#a3c43e8db82593057cd61f3e2722a3286", null ],
    [ "isRequired", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys.html#a17907a844615aad5a521d9fbe459cbec", null ],
    [ "LOADER_FILTER_FIELD", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys.html#a313ec38524e7f0c3945324ab848a232d", null ],
    [ "LOADER_FILTER_FORMAT", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys.html#a87a0248883450c84a65bddd81ba25bf0", null ],
    [ "LOADER_HAS_END", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys.html#afa1a3040da62ea13ac2cb415e9007732", null ],
    [ "LOADER_SLEEP_TIME", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys.html#a0db13ff0812392917ae612df76c271c5", null ],
    [ "LOADER_TIMEOUT", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_global_loader_config_keys.html#a4b56f6985fbac862fba7424a88a81685", null ]
];