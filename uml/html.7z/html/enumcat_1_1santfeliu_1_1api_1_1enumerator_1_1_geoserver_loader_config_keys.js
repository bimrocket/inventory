var enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys =
[
    [ "getDescription", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#a719d979c8381e2c9bb7561f1721737ae", null ],
    [ "getKey", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#aba5a8b3f1cbf9f5681b424bce1da4b48", null ],
    [ "isRequired", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#a04dba66824930a212c821163847aa12d", null ],
    [ "LOADER_AUTH", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#a4664570d1808ca742760c79a958c2182", null ],
    [ "LOADER_FORMAT", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#a2b9ddfb5cf77c69c5409fbd0daa28b73", null ],
    [ "LOADER_JSON_PATH_LOCAL_ID", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#adced63da1d28cb5608a3d28c05cf6529", null ],
    [ "LOADER_LAYERS_MULTIPLE", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#acdbcada5a2b7159656fd0bbf6c64293e", null ],
    [ "LOADER_PARAMS", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#ada6c2ee377224af4cd1532ec50b06c2d", null ],
    [ "LOADER_PASSWORD", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#a44789490b0f239b0f61a309dcf3d147e", null ],
    [ "LOADER_URL", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#ad55b61e8e4d081dc2c8ae5e7c4007580", null ],
    [ "LOADER_USERNAME", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_geoserver_loader_config_keys.html#acba4f7f6c4e62a178abde3a133997431", null ]
];