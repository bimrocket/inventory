var namespacecat_1_1santfeliu_1_1api_1_1beans =
[
    [ "LoaderJsonObject", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_json_object.html", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_json_object" ],
    [ "LoaderResponse", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response" ],
    [ "ResponseWfsContainer", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_response_wfs_container.html", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_response_wfs_container" ]
];