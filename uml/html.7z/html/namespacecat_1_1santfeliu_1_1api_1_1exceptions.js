var namespacecat_1_1santfeliu_1_1api_1_1exceptions =
[
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception" ]
];