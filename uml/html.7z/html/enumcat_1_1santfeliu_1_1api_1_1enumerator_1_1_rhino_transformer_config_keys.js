var enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys =
[
    [ "getDescription", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#af5746edb437c01a7559ea847a3ef5708", null ],
    [ "getKey", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#a748df92d29c44028331e910dcce88cfd", null ],
    [ "isRequired", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#ac14f9c86f545dc4b17da887869ffef05", null ],
    [ "TRANSFORMER_JAVASCRIPT_SCRIPT", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#af6d795a1f068710ba39fac6329d3503f", null ],
    [ "TRANSFORMER_JSON_PATH_LOCAL_ID", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#ae2a4f0100ce76c21cc277b428a83c198", null ],
    [ "TRANSFORMER_JSON_PATH_LOCAL_MODEL_ID", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#a0cc75d7a6e156c76ce466cea8c25bf7e", null ],
    [ "TRANSFORMER_MODEL_INVENTORY_NAME", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#a7e1f5a84eceb08ee8b75d4b713176c9c", null ],
    [ "TRANSFORMER_SCRIPT_SCOPE_GLOBAL_ID_NAME", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#af8a9b861b67b60e454437996816382d7", null ],
    [ "TRANSFORMER_SCRIPT_SCOPE_JSON_OBJECT_NAME", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#a21a14a2465615fbfbe40e597c5864a2b", null ],
    [ "TRANSFORMER_SCRIPT_SCOPE_MODEL_GLOBAL_ID_NAME", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#a6b4974ed32d4931f3a1b747d8b49903a", null ],
    [ "TRANSFORMER_TRANSFORM_LOCAL_ID", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_rhino_transformer_config_keys.html#a95fe8b02b55f9d06abb91997e122d375", null ]
];