var namespaces_dup =
[
    [ "cat", null, [
      [ "santfeliu", null, [
        [ "api", null, [
          [ "api", "namespacecat_1_1santfeliu_1_1api_1_1api.html", "namespacecat_1_1santfeliu_1_1api_1_1api" ],
          [ "beans", "namespacecat_1_1santfeliu_1_1api_1_1beans.html", "namespacecat_1_1santfeliu_1_1api_1_1beans" ],
          [ "components", "namespacecat_1_1santfeliu_1_1api_1_1components.html", "namespacecat_1_1santfeliu_1_1api_1_1components" ],
          [ "config", "namespacecat_1_1santfeliu_1_1api_1_1config.html", "namespacecat_1_1santfeliu_1_1api_1_1config" ],
          [ "controllers", "namespacecat_1_1santfeliu_1_1api_1_1controllers.html", "namespacecat_1_1santfeliu_1_1api_1_1controllers" ],
          [ "dto", "namespacecat_1_1santfeliu_1_1api_1_1dto.html", "namespacecat_1_1santfeliu_1_1api_1_1dto" ],
          [ "enumerator", "namespacecat_1_1santfeliu_1_1api_1_1enumerator.html", "namespacecat_1_1santfeliu_1_1api_1_1enumerator" ],
          [ "exceptions", "namespacecat_1_1santfeliu_1_1api_1_1exceptions.html", "namespacecat_1_1santfeliu_1_1api_1_1exceptions" ],
          [ "loaders", "namespacecat_1_1santfeliu_1_1api_1_1loaders.html", "namespacecat_1_1santfeliu_1_1api_1_1loaders" ],
          [ "model", "namespacecat_1_1santfeliu_1_1api_1_1model.html", "namespacecat_1_1santfeliu_1_1api_1_1model" ],
          [ "repo", "namespacecat_1_1santfeliu_1_1api_1_1repo.html", "namespacecat_1_1santfeliu_1_1api_1_1repo" ],
          [ "senders", "namespacecat_1_1santfeliu_1_1api_1_1senders.html", "namespacecat_1_1santfeliu_1_1api_1_1senders" ],
          [ "service", "namespacecat_1_1santfeliu_1_1api_1_1service.html", "namespacecat_1_1santfeliu_1_1api_1_1service" ],
          [ "transformers", "namespacecat_1_1santfeliu_1_1api_1_1transformers.html", "namespacecat_1_1santfeliu_1_1api_1_1transformers" ],
          [ "utils", "namespacecat_1_1santfeliu_1_1api_1_1utils.html", "namespacecat_1_1santfeliu_1_1api_1_1utils" ],
          [ "InventariMunicipalApp", "classcat_1_1santfeliu_1_1api_1_1_inventari_municipal_app.html", null ]
        ] ]
      ] ]
    ] ]
];