var classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db =
[
    [ "ConnectorStatusDb", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#ab7bd87629dde6419eebdd94baffcbb9f", null ],
    [ "getConnectorEndDate", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#abbebbd41e83bce12c6b60eb47ecf1a5a", null ],
    [ "getConnectorName", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#a711a3dd61ca126125a4fc6dadc278e39", null ],
    [ "getConnectorStartDate", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#af855717b3490ddf8c9d4274243aed81f", null ],
    [ "getConnectorStatus", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#aae95730de7b7af7dbb33ca6e6034013f", null ],
    [ "setConnectorEndDate", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#ad83aa15f280eccd61bf4582f802bdfae", null ],
    [ "setConnectorName", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#abca2ba11fc7d38e7a236df80af393c69", null ],
    [ "setConnectorStartDate", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#a8332509968683554734234d83f8b6103", null ],
    [ "setConnectorStatus", "classcat_1_1santfeliu_1_1api_1_1model_1_1_connector_status_db.html#a1dbdb84fb9cd4d96f5c0f69b03387c1e", null ]
];