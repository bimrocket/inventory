var classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception =
[
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#a00dd4ced0e0894a46298ae3767407745", null ],
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#a08df8e08bc1750323777e02e508e2147", null ],
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#af0d7c6c9826d31efb574cee36da06ebf", null ],
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#ab9c630f6ba3c56e26d74199493d9ecda", null ],
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#afaf700db385def67b03475436cbf9d36", null ],
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#a158df76ac5be08174f80318bc3b18320", null ],
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#a35b5c08b203214865848c448f10c486c", null ],
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#a24e85f6884ff21c58ce0591ccf13eab5", null ],
    [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#ab2d8481ab5c9a596323bbd5cd09bf81e", null ],
    [ "getApiError", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html#a9fb186be0fa28d42222e944187a35732", null ]
];