var namespacecat_1_1santfeliu_1_1api_1_1senders =
[
    [ "GeoserverSender", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_geoserver_sender.html", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_geoserver_sender" ],
    [ "JSONKafkaSender", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_j_s_o_n_kafka_sender.html", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_j_s_o_n_kafka_sender" ],
    [ "LogSender", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_log_sender.html", "classcat_1_1santfeliu_1_1api_1_1senders_1_1_log_sender" ]
];