var classcat_1_1santfeliu_1_1api_1_1config_1_1_simple_cors_filter =
[
    [ "destroy", "classcat_1_1santfeliu_1_1api_1_1config_1_1_simple_cors_filter.html#a0ec14b4aae17abeba4907ec789799874", null ],
    [ "doFilter", "classcat_1_1santfeliu_1_1api_1_1config_1_1_simple_cors_filter.html#ad3bacb95db7355f49e01aa9d81c2a943", null ],
    [ "init", "classcat_1_1santfeliu_1_1api_1_1config_1_1_simple_cors_filter.html#a14c1056a0008026b35462a098a40342a", null ]
];