var classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_api_service =
[
    [ "createConnector", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_api_service.html#abb2a8d21141ffdcf48a9b2889356ad0d", null ],
    [ "getAllComponents", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_api_service.html#a47251cbb59f8f2a8361fbd0ede117a31", null ],
    [ "getAllConnectors", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_api_service.html#a62c646d365fca9227f8bb2ae8e2068ab", null ],
    [ "getConnector", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_api_service.html#ab4be2cdf81d26e3f228b8993bdb05480", null ],
    [ "updateConnector", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_api_service.html#aab4f81cb95d256e449560a6a16677391", null ]
];