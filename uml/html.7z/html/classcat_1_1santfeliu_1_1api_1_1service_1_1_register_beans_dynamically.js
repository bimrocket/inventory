var classcat_1_1santfeliu_1_1api_1_1service_1_1_register_beans_dynamically =
[
    [ "setBeanFactory", "classcat_1_1santfeliu_1_1api_1_1service_1_1_register_beans_dynamically.html#abb2cd0a6cced7bb55124fa22ed807b67", null ]
];