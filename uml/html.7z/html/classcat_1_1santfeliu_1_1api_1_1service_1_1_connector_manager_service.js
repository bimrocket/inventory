var classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_manager_service =
[
    [ "connectorStats", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_manager_service.html#a4c5a7c0b7e61ae3c36f7a4bc2101a6a0", null ],
    [ "connectorStatus", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_manager_service.html#aab5942a6cb35ee720d50fb4903d739e7", null ],
    [ "startConnector", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_manager_service.html#aac51b6ffbed7187005294317099ff24b", null ],
    [ "stopConnector", "classcat_1_1santfeliu_1_1api_1_1service_1_1_connector_manager_service.html#aff84b79653922eccf4351d64bd82e543", null ]
];