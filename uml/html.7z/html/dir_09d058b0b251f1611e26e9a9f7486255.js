var dir_09d058b0b251f1611e26e9a9f7486255 =
[
    [ "GeoserverLoader.java", "_geoserver_loader_8java.html", [
      [ "GeoserverLoader", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_geoserver_loader.html", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_geoserver_loader" ]
    ] ],
    [ "JSONKafkaLoader.java", "_j_s_o_n_kafka_loader_8java.html", [
      [ "JSONKafkaLoader", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_j_s_o_n_kafka_loader.html", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_j_s_o_n_kafka_loader" ]
    ] ]
];