var dir_4912399c854964ebbd3f02439f32e393 =
[
    [ "ConnectorApiController.java", "_connector_api_controller_8java.html", [
      [ "ConnectorApiController", "classcat_1_1santfeliu_1_1api_1_1controllers_1_1_connector_api_controller.html", "classcat_1_1santfeliu_1_1api_1_1controllers_1_1_connector_api_controller" ]
    ] ]
];