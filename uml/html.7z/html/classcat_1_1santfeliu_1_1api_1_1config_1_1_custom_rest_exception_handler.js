var classcat_1_1santfeliu_1_1api_1_1config_1_1_custom_rest_exception_handler =
[
    [ "customHandleApiError", "classcat_1_1santfeliu_1_1api_1_1config_1_1_custom_rest_exception_handler.html#a82a13e603cd90cb0379227c8924724f1", null ],
    [ "exceptionHandleApiError", "classcat_1_1santfeliu_1_1api_1_1config_1_1_custom_rest_exception_handler.html#aedd7d8d9a69407aaaa2103f419702408", null ]
];