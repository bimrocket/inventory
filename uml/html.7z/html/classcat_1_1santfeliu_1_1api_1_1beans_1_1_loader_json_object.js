var classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_json_object =
[
    [ "LoaderJsonObject", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_json_object.html#a6a98f9d6da5c42c37838960bfe13ec60", null ],
    [ "getElement", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_json_object.html#ad9dc94d23ec146d090f8c9c4d4d8fa44", null ],
    [ "getGlobalId", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_json_object.html#a038db84bce182baf7d92cbab6982f07b", null ],
    [ "setElement", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_json_object.html#a4214a15fac07ff6789cdf8de331f34f3", null ],
    [ "setGlobalId", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_json_object.html#ab08871a6231c6d06c90ecb82ecdc15c3", null ]
];