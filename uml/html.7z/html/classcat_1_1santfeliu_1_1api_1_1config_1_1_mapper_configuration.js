var classcat_1_1santfeliu_1_1api_1_1config_1_1_mapper_configuration =
[
    [ "modelMapper", "classcat_1_1santfeliu_1_1api_1_1config_1_1_mapper_configuration.html#a7d55e8eaf1e17180867e51bd063082e7", null ]
];