var enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_locale_enum =
[
    [ "getKey", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_locale_enum.html#a743f8550025ac4b19ceeb93fedaf100f", null ],
    [ "is", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_locale_enum.html#adb18560ee3786cbe31bad7f4a233913a", null ],
    [ "CAT", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_locale_enum.html#a9a1c7e7241e35e3a747c08f7c3f16bb9", null ],
    [ "EN", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_locale_enum.html#a039ed0155202ff52d69ecc44b3b1ea27", null ],
    [ "ES", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_locale_enum.html#a9686f1691f45f1f10e33a660a038ecf0", null ]
];