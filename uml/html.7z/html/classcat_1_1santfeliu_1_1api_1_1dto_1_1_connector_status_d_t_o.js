var classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o =
[
    [ "ConnectorStatusDTO", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#a670035bf62520353d165e89960a5ce1b", null ],
    [ "ConnectorStatusDTO", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#ab132f6b8161b941898baa24d59706335", null ],
    [ "getConnectorEndDate", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#a37f8b6e785e4e91247681809edf13db5", null ],
    [ "getConnectorName", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#a6ee26425a853c5a17f0de4509a58a7e0", null ],
    [ "getConnectorStartDate", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#a5d8c9c1ae6e4f41a21df00277e5e05d9", null ],
    [ "getConnectorStatus", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#ae8d9669ca977abf64b57b42ea83d0a03", null ],
    [ "setConnectorEndDate", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#a6607273005ed753d0f11ac2f05349902", null ],
    [ "setConnectorName", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#a22197d81b4809f1db59e30b3edbbd9fa", null ],
    [ "setConnectorStartDate", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#a90630be2ce039c0c71eddee7165e7dc0", null ],
    [ "setConnectorStatus", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_status_d_t_o.html#add024d2f4da62e03319e55879206f871", null ]
];