var classcat_1_1santfeliu_1_1api_1_1config_1_1_angular_configuration =
[
    [ "addResourceHandlers", "classcat_1_1santfeliu_1_1api_1_1config_1_1_angular_configuration.html#a0906a3b4473e09abd7364d1c28d763ef", null ],
    [ "addViewControllers", "classcat_1_1santfeliu_1_1api_1_1config_1_1_angular_configuration.html#a9031eb1ad2f65aa366a643260a2b5b68", null ],
    [ "configureContentNegotiation", "classcat_1_1santfeliu_1_1api_1_1config_1_1_angular_configuration.html#a1ca07b688d0b961716bfcf7b8c279d67", null ]
];