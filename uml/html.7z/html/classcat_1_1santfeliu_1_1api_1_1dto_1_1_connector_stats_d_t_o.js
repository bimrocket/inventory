var classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o =
[
    [ "ConnectorStatsDTO", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a94b71d8975296b4681b7888cf0752c3d", null ],
    [ "getExecutionConnectorName", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#adba90dfe5e1c7e155bd089c086467346", null ],
    [ "getExecutionEndDate", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a619b0f7970eeb275aabcd5ccee28e5fb", null ],
    [ "getExecutionFinalState", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a74215b23bf2ead42627f6266316735d4", null ],
    [ "getExecutionId", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#ad987eaa069f6f82a7e1311757f5a8640", null ],
    [ "getExecutionObjectsDeleted", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a013ec8e4cec018ff94ed95393301d0ac", null ],
    [ "getExecutionObjectsLoaded", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a2c6c140ac091d7d39d6cf3a52473f157", null ],
    [ "getExecutionObjectsSent", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a736a00b82a206a6ae97d100844f01de5", null ],
    [ "getExecutionObjectsTransformed", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#aad466f23fcdc9b4c1a8309c72a9a186e", null ],
    [ "getExecutionStartDate", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#aa6ded0a2ace8d23beb8fec800ad69d50", null ],
    [ "setExecutionConnectorName", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a50b0dae02ecad2ae716325886d9143fb", null ],
    [ "setExecutionEndDate", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a533ac955e8c8e85b433ce64d9b84127b", null ],
    [ "setExecutionFinalState", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a5c548f69dc2c2290ffcc2f5e6f226ef5", null ],
    [ "setExecutionId", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a67290e59609155919a1b207700815f60", null ],
    [ "setExecutionObjectsDeleted", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#adb3ec27f66b259cc1aa18b101e7cc7f6", null ],
    [ "setExecutionObjectsLoaded", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a2407ef27d75fb72bc202990c7f16757b", null ],
    [ "setExecutionObjectsSent", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a1a990cb5d05812e8dfcc319e62f3392d", null ],
    [ "setExecutionObjectsTransformed", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#a532ef45db1b47453d870710019e408d8", null ],
    [ "setExecutionStartDate", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_connector_stats_d_t_o.html#ac5926f478dc8be4d14c896b55f2423e4", null ]
];