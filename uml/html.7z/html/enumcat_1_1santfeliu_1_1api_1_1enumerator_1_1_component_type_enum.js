var enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_component_type_enum =
[
    [ "getName", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_component_type_enum.html#a10975828c6be2a518dbe44362e15d185", null ],
    [ "LOADER", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_component_type_enum.html#a3f7bfb8467f408ab9ac6564d72372108", null ],
    [ "SENDER", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_component_type_enum.html#adcae5ea1d0aff45323f07f6f509f85c8", null ],
    [ "TRANSFORMER", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_component_type_enum.html#a5e56e111f7091595b6c13da1c7d77bb0", null ]
];