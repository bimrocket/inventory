var classcat_1_1santfeliu_1_1api_1_1loaders_1_1_j_s_o_n_kafka_loader =
[
    [ "load", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_j_s_o_n_kafka_loader.html#a4c32817dc42a8c6bbf98724a430c5575", null ],
    [ "stop", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_j_s_o_n_kafka_loader.html#ab870cf6d6fe927f3633f7d909a467e76", null ]
];