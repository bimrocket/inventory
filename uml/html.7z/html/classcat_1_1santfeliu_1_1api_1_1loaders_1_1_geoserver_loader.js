var classcat_1_1santfeliu_1_1api_1_1loaders_1_1_geoserver_loader =
[
    [ "load", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_geoserver_loader.html#aecdc6ab5af412ad4354ece82bddc6fc2", null ],
    [ "stop", "classcat_1_1santfeliu_1_1api_1_1loaders_1_1_geoserver_loader.html#ab07e37f525d0b822dc7811d7d08e77c3", null ]
];