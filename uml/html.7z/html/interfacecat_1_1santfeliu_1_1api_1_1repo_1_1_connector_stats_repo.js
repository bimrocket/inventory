var interfacecat_1_1santfeliu_1_1api_1_1repo_1_1_connector_stats_repo =
[
    [ "findByExecutionConnectorNameOrderByExecutionStartDateDesc", "interfacecat_1_1santfeliu_1_1api_1_1repo_1_1_connector_stats_repo.html#a90c2fdb8be0b8ad3b1618515aa62553e", null ]
];