var classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_transformer =
[
    [ "transform", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_transformer.html#a7788d44e96caa9c5ce5992de54199693", null ],
    [ "globalIdRepo", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_transformer.html#a7b737026c229618a83f52d00ffafec84", null ]
];