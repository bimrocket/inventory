var classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o =
[
    [ "PageStatsDTO", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#a8e1c29df1f93df4bb89696bc981fa0cb", null ],
    [ "getPage", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#aaa70be6fc181020acbfcd98c1b1aa2fa", null ],
    [ "getSize", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#a454e66e6a08cb18e88dee0367863ba5d", null ],
    [ "getStats", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#abdfc3bdf899b0b8d56c53a2d85781c3d", null ],
    [ "getTotalELements", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#ae9a046560c2b91585f88234fed993f1c", null ],
    [ "getTotalPages", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#a4ed9721e2ecd8d7c1f22453848a3ffc2", null ],
    [ "setPage", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#acb6c7a422d74a31866359938fa556504", null ],
    [ "setSize", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#a75f18172388eee906ae69ed4e0a7ea7d", null ],
    [ "setStats", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#a79aa2b902921271c2f5b941358966de1", null ],
    [ "setTotalELements", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#a0b0c7df4edab142ef3bd2c9fd4729745", null ],
    [ "setTotalPages", "classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html#ae5764a2025b7a8ef1bf0cd25ac36a663", null ]
];