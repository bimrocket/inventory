var classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance =
[
    [ "ConnectorInstance", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a9ea225a02ceb96c13b643832c3593cc9", null ],
    [ "destroy", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#ada94489acb9713b13896e31f430785b3", null ],
    [ "getConnector", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a015ea87d01fb35627fbd4fd56e567d3a", null ],
    [ "getConnectorLoader", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#abfa15277b07ab401433dbf0d3c6fa305", null ],
    [ "getConnectorSender", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a4d0b53c04998526d10b9f86d14ce457b", null ],
    [ "getConnectorStats", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a2ce24876ec6632cf819b0e0f0b99557b", null ],
    [ "getConnectorStatus", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#aea403983e9e0b5032e64c52768833465", null ],
    [ "getConnectorTransformer", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a82e4ee5868d75f76d03ed255a3756ef7", null ],
    [ "isEnd", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#afe41c422207ce151633ab1e0d5ce91a7", null ],
    [ "setConnector", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a713f10a757bb691f85ea2eb284410e15", null ],
    [ "setConnectorLoader", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#aca92c3539a30ce3d1c1010656e923cfb", null ],
    [ "setConnectorSender", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a7f3d7b917ee36c50706a6b88b9d1f830", null ],
    [ "setConnectorStats", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a8c23e3a045ed60db8b15f09ad9ae9813", null ],
    [ "setConnectorStatus", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a02f9ea7fd5b920ea6c09012789890523", null ],
    [ "setConnectorTransformer", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a378b21f09ba98dff5ea40b3d87792f85", null ],
    [ "setEnd", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#a9e08f1cb4ec31245cc46c76766a35ffd", null ],
    [ "shouldEnd", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#ae6babff3cda997aa4bb1320353625a1b", null ],
    [ "stop", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_instance.html#aadfc7a702b47472b94d755e688f4413b", null ]
];