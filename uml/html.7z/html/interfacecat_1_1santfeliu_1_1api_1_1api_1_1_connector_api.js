var interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api =
[
    [ "connectorComponents", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#a4bc4627a995c4537c8f9264e19c7f3e7", null ],
    [ "connectorStats", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#a2f53d24a385b08ab55d213cc9750d496", null ],
    [ "connectorStatus", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#a4ed614323e06425ae705b9bbfb2c6f24", null ],
    [ "createConnector", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#a4278a23c8fa0f2c5540c76db37d5a912", null ],
    [ "getConnector", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#ab8aec8fa8e9a4555cdab36f3aef6a95c", null ],
    [ "getConnectors", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#aa3adf10b2d2caceb2dd9d818d833bb37", null ],
    [ "startConnector", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#aad7a7a0e0dd8f31eb5575ed112f407db", null ],
    [ "stopConnector", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#ac18dd30a11c1196db8015469de8f0728", null ],
    [ "updateConnector", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html#a179ada6cff36cbd7bf95ac301ddc7127", null ]
];