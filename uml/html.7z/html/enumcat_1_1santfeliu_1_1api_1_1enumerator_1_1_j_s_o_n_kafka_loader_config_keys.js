var enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_loader_config_keys =
[
    [ "getDescription", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_loader_config_keys.html#a29f53218514912bc32ee297fcdcb0d38", null ],
    [ "getKey", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_loader_config_keys.html#a853fadac3766f6b762994d3c9710d051", null ],
    [ "isRequired", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_loader_config_keys.html#a304145eb9861536b2c184cd141c60c54", null ],
    [ "KAFKA_GROUP_ID", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_loader_config_keys.html#a5fba56a6dc629c3a736c7bbd460f40f8", null ],
    [ "KAFKA_TOPIC_NAME", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_loader_config_keys.html#a35635cd61ac5226fd0b2216b36dc7c05", null ],
    [ "LOADER_HAS_END", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_loader_config_keys.html#a19d4f2dc640b3b9b98f77b7cb284edf5", null ]
];