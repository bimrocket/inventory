var classcat_1_1santfeliu_1_1api_1_1config_1_1_authentication_entry_point =
[
    [ "afterPropertiesSet", "classcat_1_1santfeliu_1_1api_1_1config_1_1_authentication_entry_point.html#a1dcae348cc959771fb3c1573a78953a1", null ],
    [ "commence", "classcat_1_1santfeliu_1_1api_1_1config_1_1_authentication_entry_point.html#aaaf4441f55a92efdb69d747ff5b0263f", null ]
];