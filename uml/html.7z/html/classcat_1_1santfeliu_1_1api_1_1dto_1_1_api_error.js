var classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error =
[
    [ "ApiError", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a1695e22bba570ecaf08fdea2fa89b43b", null ],
    [ "ApiError", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#ad61f01d06514c824fcab89a2c7edbf4a", null ],
    [ "ApiError", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a689e28f4b4cd89b84582a303f2e98223", null ],
    [ "ApiError", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#afbf2d0dc3d6733f5979f2b1d40c277ac", null ],
    [ "ApiError", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a367c765cba4fcdfeb1795027fb739e26", null ],
    [ "ApiError", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a8213a6181545397bc0659328f8132cad", null ],
    [ "getErrorCode", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a4fdc8f77b73a2f2761183820f26b6a06", null ],
    [ "getErrors", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#ac57edef0b5f02749d4a92645ec1cd094", null ],
    [ "getMessage", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#ab8cb8179f232032d57bda5549502ed24", null ],
    [ "getParams", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a33e6ee918f48272e7cd68d125f9696cf", null ],
    [ "getStatus", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#ac08ea16bf95526198e76e14e0bffe852", null ],
    [ "setErrorCode", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#aa22b298487886910441412c926dcc6db", null ],
    [ "setErrors", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a73c8c8ee4e7d5f8ed3a07177e7f4c3e6", null ],
    [ "setMessage", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a5ff86878aac3fcb08883ce0aa5a0a76c", null ],
    [ "setParams", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#a60f674d7a52d91850354449e6ab5ae22", null ],
    [ "setStatus", "classcat_1_1santfeliu_1_1api_1_1dto_1_1_api_error.html#ab84b2ae6b22017cdff0e8719bd4368fa", null ]
];