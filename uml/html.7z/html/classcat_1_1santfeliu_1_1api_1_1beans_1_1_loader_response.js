var classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response =
[
    [ "LoaderResponse", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html#ad38e0c7bfc92e854c6794e568112d280", null ],
    [ "LoaderResponse", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html#ac89db9c2f499646860e2dd1485272763", null ],
    [ "getFormat", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html#adf24f77826295b3fa6bd73038529ded0", null ],
    [ "getResponse", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html#a395e4fd638193e62cea6c7c11dd41294", null ],
    [ "isValid", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html#aaefb1b9956324483283c0e95eed66b5f", null ],
    [ "setFormat", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html#a759a6cb5515b8d25855356e92f6ee405", null ],
    [ "setResponse", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html#a3deca91762227863214a2c9c3ef12e69", null ],
    [ "setValid", "classcat_1_1santfeliu_1_1api_1_1beans_1_1_loader_response.html#a60ed9133d04c977e3651181ac047b4e4", null ]
];