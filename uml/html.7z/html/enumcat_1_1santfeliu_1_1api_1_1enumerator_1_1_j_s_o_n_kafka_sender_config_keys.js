var enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_sender_config_keys =
[
    [ "getDescription", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_sender_config_keys.html#a980e0a057e0a5197c097c873ad69da96", null ],
    [ "getKey", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_sender_config_keys.html#a7fa1c2ce571e2ddfa10b14b275ce6ce7", null ],
    [ "isRequired", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_sender_config_keys.html#a4454a38f96eaf087e6fffae778c15147", null ],
    [ "KAFKA_PARTITIONS", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_sender_config_keys.html#ae7eb868c2c92a537cf5c024a850d32a5", null ],
    [ "KAFKA_TOPIC_NAME", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_j_s_o_n_kafka_sender_config_keys.html#a6e634b6e15b4b1a1ed74a96ca1013fb0", null ]
];