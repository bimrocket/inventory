var classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_sender =
[
    [ "send", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_sender.html#a7df220a0022fd374a5f2c52c0658f41c", null ],
    [ "globalIdRepo", "classcat_1_1santfeliu_1_1api_1_1components_1_1_connector_sender.html#ace534b11e6b75662cfd16961c99d7813", null ]
];