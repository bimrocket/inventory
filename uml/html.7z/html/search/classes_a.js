var searchData=
[
  ['pagestatsdto_497',['PageStatsDTO',['../classcat_1_1santfeliu_1_1api_1_1model_1_1_page_stats_d_t_o.html',1,'cat::santfeliu::api::model']]]
];
