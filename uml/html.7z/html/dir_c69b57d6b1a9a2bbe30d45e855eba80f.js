var dir_c69b57d6b1a9a2bbe30d45e855eba80f =
[
    [ "ApiErrorException.java", "_api_error_exception_8java.html", [
      [ "ApiErrorException", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception.html", "classcat_1_1santfeliu_1_1api_1_1exceptions_1_1_api_error_exception" ]
    ] ]
];