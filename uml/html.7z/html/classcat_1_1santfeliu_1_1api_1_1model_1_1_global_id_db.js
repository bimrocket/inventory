var classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db =
[
    [ "GlobalIdDb", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#aa4203700fbd63e07b115f9a868c53f12", null ],
    [ "equals", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#ad047c65259d24e03c7d14cb84c8d398a", null ],
    [ "getGlobalId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#ab477167482296a39791e035b49eb7ae5", null ],
    [ "getInventoryName", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#aeb916dd8879794eb5ad6312d58b65f19", null ],
    [ "getLocalId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#a284d27552760d25679bd7dc8be0bad8e", null ],
    [ "getPrimaryKey", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#a147d53028b4216abb50151475692e7aa", null ],
    [ "hashCode", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#adbf8331efeb00b69919fb64dd6bb55bb", null ],
    [ "setGlobalId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#a180f15a4c88fc2ff8c51424448fadf51", null ],
    [ "setInventoryName", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#a666c30b89ba28d7bdcea63c34ffba61e", null ],
    [ "setLocalId", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#aa4da0c4f175614becb3d835788b8f97c", null ],
    [ "toString", "classcat_1_1santfeliu_1_1api_1_1model_1_1_global_id_db.html#a798c6616d0364be58e9cd8f532ef3741", null ]
];