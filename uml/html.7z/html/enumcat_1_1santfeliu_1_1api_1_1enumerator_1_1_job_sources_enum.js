var enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_job_sources_enum =
[
    [ "getValue", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_job_sources_enum.html#acc50be049ef014a9191ae82d716d5713", null ],
    [ "GEOSERVER", "enumcat_1_1santfeliu_1_1api_1_1enumerator_1_1_job_sources_enum.html#af5b8d22327bb28ede9fbafd728399e7c", null ]
];