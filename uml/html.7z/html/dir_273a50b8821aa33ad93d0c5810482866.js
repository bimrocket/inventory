var dir_273a50b8821aa33ad93d0c5810482866 =
[
    [ "ConnectorApi.java", "_connector_api_8java.html", [
      [ "ConnectorApi", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api.html", "interfacecat_1_1santfeliu_1_1api_1_1api_1_1_connector_api" ]
    ] ]
];